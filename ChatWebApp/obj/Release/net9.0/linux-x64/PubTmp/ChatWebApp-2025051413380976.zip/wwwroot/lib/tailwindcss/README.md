tailwindcss version 4.0.3
https://github.com/tailwindlabs/tailwindcss
License: MIT

This template uses only `preflight.css`, the CSS reset stylesheet from Tailwind. For simplicity, this template doesn't use a complete deployment of Tailwind. If you want to use the full Tailwind library, remove `preflight.css` and reference the full version of Tailwind.

To update, replace the `preflight.css` file with the one in an updated build from https://www.npmjs.com/package/tailwindcss
